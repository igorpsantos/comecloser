

#include "profile.h"

void Profile::displayProfile()
{
    string attributeToChoose[] = {"Esportes", "Sair", "Cinema", "Netflix", "Beber", "Viajar", "Ler", "Jogos", "Fazer Amizades", "Ficar em casa", "Pets", "\0"};

    cout << "USUARIO\n* Nome: " << name << "\n* E-mail: " << email << "\n* Sexo: " << gender << "\n* Idade: " << age
    << "\n* Localizacao: " << location << "\n* Curso: " <<
    school << "\n* Coisas que gosto (interesses): \n\n";

    for(int i = 0; i < 4; i++)
        if(attributes[i] == 0)
            cout << "*Nao informado\n";
        else cout << "*" << attributeToChoose[attributes[i] - 1] << "\n";

    cout << "\n";
}

int Profile::getDistance(){return this->distance;}

void Profile::setDistance(int value){
    this->distance = value;
}

void Profile::save_profile()
{
    int counter = 0;

    FILE * verify;

    char new_text[200];

    do{

        sprintf(new_text, "My Profiles/profile %d.txt", counter);

        verify = fopen(new_text, "r");

        if(verify != NULL)
            counter++;

    } while (verify != NULL);

    fclose(verify);

    FILE * profile_save = fopen(new_text, "w+");

    fprintf(profile_save, "%s", this->name.c_str());
    fprintf(profile_save, "%s", this->email.c_str());
    fprintf(profile_save, "%s\n", this->gender);
    fprintf(profile_save, "%d\n", this->age);
    fprintf(profile_save, "%s", this->location.c_str());
    fprintf(profile_save, "%s\n", this->school.c_str());
    fprintf(profile_save, "%d\n", this->attributes[0]);
    fprintf(profile_save, "%d\n", this->attributes[1]);
    fprintf(profile_save, "%d\n", this->attributes[2]);
    fprintf(profile_save, "%d\n", this->attributes[3]);

    fclose(profile_save);
}

void Profile::save_profile_others()
{
    static int counter = 0;

    FILE * verify;

    char new_text[200];

    sprintf(new_text, "Matchs Profiles/profile %d.txt", counter++);

    FILE * profile_save = fopen(new_text, "w+");

    fprintf(profile_save, "%s\n", this->name.c_str());
    fprintf(profile_save, "%s\n", this->email.c_str());
    fprintf(profile_save, "%s\n", this->gender.c_str());
    fprintf(profile_save, "%d\n", this->age);
    fprintf(profile_save, "%s\n", this->location.c_str());
    fprintf(profile_save, "%s\n", this->school.c_str());
    fprintf(profile_save, "%d\n", this->attributes[0]);
    fprintf(profile_save, "%d\n", this->attributes[1]);
    fprintf(profile_save, "%d\n", this->attributes[2]);
    fprintf(profile_save, "%d\n", this->attributes[3]);

    fclose(profile_save);
}

void Profile::displayProfile_new(){

    string attributeToChoose[] = {"Esportes", "Sair", "Cinema", "Netflix", "Beber", "Viajar", "Ler", "Jogos", "Fazer Amizades", "Ficar em casa", "Pets", "\0"};

    printf("\n\n");
    cout << "===================" << endl;
    cout << "\nNome : " << this->name;
    cout << "Email : " << this->email;
    cout << "Sexo : " << this->gender;
    cout << "Idade : " << this->age << endl;
    cout << "Localizacao : " << this->location;
    cout << "Curso : " << this->school << endl;

    for(int i = 0; i < 4;i++){
        cout << attributeToChoose[this->attributes[i]] << endl;
    }
    cout << "===================" << endl;
    printf("\n\n");
}

int Profile::getProfileAtt1(){return this->attributes[0];}
int Profile::getProfileAtt2(){return this->attributes[1];}
int Profile::getProfileAtt3(){return this->attributes[2];}
int Profile::getProfileAtt4(){return this->attributes[3];}
string Profile::getGender(){return this->gender;}

int Attribute::getAttValue1(){return this->attributeValue1;}
int Attribute::getAttValue2(){return this->attributeValue2;}
int Attribute::getAttValue3(){return this->attributeValue3;}
int Attribute::getAttValue4(){return this->attributeValue4;}
int Attribute::getAttValue5(){return this->attributeValue5;}
int Attribute::getAttValue6(){return this->attributeValue6;}
int Attribute::getAttValue7(){return this->attributeValue7;}
int Attribute::getAttValue8(){return this->attributeValue8;}
int Attribute::getAttValue9(){return this->attributeValue9;}
int Attribute::getAttValue10(){return this->attributeValue10;}
int Attribute::getAttValue11(){return this->attributeValue11;}

void Attribute::match(Profile a, int attributes[], int sexo){

    int d1 = 0, d2 = 0, d3 = 0, d4 = 0;
    int media = 0;
    int contador;
    int x[4];
    int y[4];

    for(int i = 0; i < 4; i++){
        x[i] = attributes[i];
    }

    y[0] = a.getProfileAtt1();
    y[1] = a.getProfileAtt2();
    y[2] = a.getProfileAtt3();
    y[3] = a.getProfileAtt4();

    insertionSort(x, 4);

    d1 = x[0] - y[0];
    d2 = x[1] - y[1];
    d3 = x[2] - y[2];
    d4 = x[3] - y[3];

    media = ((d1 + d2 + d3 + d4) / 4);

    if(media == 0){
        a.displayProfile_new();
        a.save_profile_others();
    }
}

// Funcao q realiza as trocas
void Attribute::swape(int &num1, int &num2)
{
   int num3 = num1;
   num1 = num2;
   num2 = num3;
}

void Attribute::insertionSort(int *vetor, int tamanho)
{
   for( int i = 1; i < tamanho; i++ ) {
	  for( int j = i; j > 0; j-- ) {
		 if( vetor[j] < vetor[j-1] )
			swape( vetor[j], vetor[j-1] );
	  }
   }
}
