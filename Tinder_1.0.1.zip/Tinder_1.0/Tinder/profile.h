#ifndef _PROFILE_
#define _PROFILE_

#include "Header.h"

class Profile
{
    protected:
    int distance;
    string name;
    string email;
    string gender;
    int age;
    string location;
    string school;

    int attributes[4];

    public:

    Profile(){}

    Profile(string name, string email, string gender, int age, string location, string school, int attributes[4]){ // construtor

        this->name = name;
        this->email = email;
        this->gender = gender;
        this->age = age;
        this->location = location;
        this->school = school;

        for(int i = 0; i < 4; i++)
        {
            this->attributes[i] = attributes[i];
        }
    }
    int getProfileAtt1();
    int getProfileAtt2();
    int getProfileAtt3();
    int getProfileAtt4();
    int getDistance();
    string getGender();
    void setDistance(int value);

    void displayProfile();

    void displayProfile_new();

    void save_profile();

    void save_profile_others();
};

class Attribute : public Profile{ // NAO SEI SE � NECESSARIO A CLASSE ATTRIBUTE SER FILHO DA CLASSE PROFILE, ESSA CLASSE � APENAS PARA DEFINIR OS VALORES DAS VARIAVEIS

    int attributeValue1 = 1; // Esportes
    int attributeValue2 = 2; // sair
    int attributeValue3 = 3; // Cinema
    int attributeValue4 = 4; // Netflix
    int attributeValue5 = 5; // Beber
    int attributeValue6 = 6; // Viajar
    int attributeValue7 = 7; // Ler
    int attributeValue8 = 8; // Jogos
    int attributeValue9 = 9; // Fazer Amizades
    int attributeValue10 = 10; // Ficar em casa
    int attributeValue11 = 11; // Pets

    public:
    Attribute(){}
    void match(Profile a, int attributes[], int sexo);
    void insertionSort(int *a, int tam);
    void swape(int &, int &);

    int getAttValue1();
    int getAttValue2();
    int getAttValue3();
    int getAttValue4();
    int getAttValue5();
    int getAttValue6();
    int getAttValue7();
    int getAttValue8();
    int getAttValue9();
    int getAttValue10();
    int getAttValue11();

};

#endif // _PROFILE_
