

#include "funcoes.h"

bool Funcs::validar_email(string email)
{
    int tamanho = email.size();

    for(int i = 0; i < tamanho; i++)
    {
        if(email[i] == '@')
        {
            if(email[i + 1] == 'u'
               && email[i + 2] == 't'
               && email[i + 3] == 'p'
               && email[i + 4] == '.'
               && email[i + 5] == 'e'
               && email[i + 6] == 'd'
               && email[i + 7] == 'u'
               && email[i + 8] == '.'
               && email[i + 9] == 'b'
               && email[i + 10] == 'r')
                return true;
            else return false;
        }
    }

    return false;
}

void Funcs::load_profiles()
{
    int counter = 0, op;

    FILE * verify;

    char new_text[200];

    cout << "\t\t\tPERFIS EXISTENTES:\n" << endl;

    do{

        sprintf(new_text, "My Profiles/profile %d.txt", counter);

        verify = fopen(new_text, "r");

        char lastname[50];

        if(verify != NULL)
        {
            fgets(lastname, 50, verify);
            cout << counter + 1 << " : " << lastname << "\n\n";
            counter++;
        }

        fclose(verify);

    } while (verify != NULL);

    FILE * my_profile;

    cout << "Entre com o perfil para carregar : ";
    cin >> op;

    sprintf(new_text, "My Profiles/profile %d.txt", op - 1);

    my_profile = fopen(new_text, "r");

    if(my_profile == NULL)
    {
        cout << "\n\nPerfil invalido !\n" << endl;
        system("pause");
        return;
    }

    counter = 0;

    string name, email, location, school;
    string gender;
    int age, attributes[4];

    while(!feof(my_profile))
    {
        char buffer[50];

        if(counter == 0)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            name = buffer;
            counter++;
        } else if(counter == 1)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            email = buffer;
            counter++;
        } else if(counter == 2)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            gender = buffer[0];
            counter++;
        } else if(counter == 3)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            age = atoi(buffer);
            counter++;
        } else if(counter == 4)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            location = buffer;
            counter++;
        } else if(counter == 5)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            school = buffer;
            counter++;
        } else if(counter == 6)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            attributes[0] = atoi(buffer);
            counter++;
        } else if(counter == 7)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            attributes[1] = atoi(buffer);
            counter++;
        } else if(counter == 8)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            attributes[2] = atoi(buffer);
            counter++;
        } else if(counter == 9)
        {
            fgets(buffer, 50, my_profile);
            buffer[strlen(buffer) - 1] = '\0';
            attributes[3] = atoi(buffer);
            counter++;
        } else fgets(buffer, 50, my_profile);
    }

    fclose(my_profile);

    Profile user(name, email, gender, age, location, school, attributes);

    system("cls");

    user.displayProfile();

    system("pause");
}


