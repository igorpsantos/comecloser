#ifndef _FUNCS_
#define _FUNCS_

#include "Header.h"

class Funcs
{
public:

    bool validar_email(string);
    void load_profiles();
};

#endif // _FUNCS_
