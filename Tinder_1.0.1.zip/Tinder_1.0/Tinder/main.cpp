#include "Header.h"
#include <dirent.h>

// A FUNCAO LE ARQUIVO DEVE ARMAZENAR NOS PERFIS OS DADOS LIDOS DIRETAMENTE DO ARQUIVO, TAMBEM NA CRIA��O DO PERFIL DE QUEM FAZ A BUSCA
// DEVE OBSERVAR QUE OS MESMOS PARAMETROS ESCOLHIDOS PARA OS ATRIBUTOS/CRITERIOS E/OU INTERESSES SER�O OS MESMOS QUE FORAM CRIADO NO ARQUIVO
// OU TAMBEM CRIAR UMA CLASSE AONDE ESSA SERIA A CLASSE PAI QUE CRIARIA O "BANCO DE DADOS DE USUARIOS" UTILIZANDO A CLASSE FILHA "PERFIL"
// PARA ARMAZENAR OS DEMAIS...

bool verifica_arquivo(char * palavra)
{
	int i;
	for(i = 0; i < strlen(palavra); i++)
	{
		if(palavra[i] =='.')
			if(palavra[i + 1] == 't'
			&& palavra[i + 2] == 'x'
			&& palavra[i + 3] == 't' )
			return true;
	}

	return false;
}

void verifica_perfil(char* diretorio, Profile a[], int cont){

    string name;
    string email;
    string aux;
    string gender;
    int age;
    string location;
    string school;

	// abrindo o arquivo
	FILE* arquivotexto = fopen(diretorio, "r"); // abre o arquivo texto para leitura
    if(arquivotexto == NULL){
        perror("nao foi possivel abrir o diretorio texto");
    }

    char buffer[100];
    int attributes[4];

    int i = 0;

    name = fgets(buffer, 100, arquivotexto);
    email = fgets(buffer, 100, arquivotexto);
    gender = fgets(buffer, 100, arquivotexto);
    age = atoi(fgets(buffer, 100, arquivotexto));
    location = fgets(buffer, 100, arquivotexto);
    school = fgets(buffer, 100, arquivotexto);
    for(i = 0; i < 4; i++)
    {
        attributes[i] = atoi(fgets(buffer, 100, arquivotexto));
    }

    a[cont] = Profile(name, email, gender, age, location, school, attributes);

    fclose(arquivotexto);
}

void percorrer(char * diretorio, int index, Profile a[])
{
	int contador = 0;
	DIR *dir;
    struct dirent *lsdir;

    dir = opendir(diretorio);

    /* print all the files and directories within directory */
    while ( ( lsdir = readdir(dir) ) != NULL )
    {

    	if(lsdir->d_name[0] != '.')
    	{


	    	char var[1000];

			strcpy(var, diretorio);
	    	strcat(var, lsdir->d_name);


	    	/*int k;

	    	for(k = 0; k < index; ++k)
	    	{
	    		printf("   ");
			}*/

			if(verifica_arquivo(lsdir->d_name) == true){
	        	//printf ("%s\n", var);
	        	verifica_perfil(var, a, ++contador);
	       	}

	        //strcat(var, "\\");
            //percorrer(var, index + 1, a);

	    }

    }

	closedir(dir);

}


void display(){ //
   // POR CAUSA DOS CARACTERES RESERVADOS COMO / \ AQUI NO PRINTF FICOU DISTORCIDO, POREM EM TELA REPRESENTA O NOME CORRETO
   printf("  ____    ___    __  __   _____      ____   _        ___    ____    _____   ____ \n");
   printf(" / ___|  / _ \\  |  \\/  | | ____|    / ___| | |      / _ \\  / ___|  | ____| |  _ \\ \n");
   printf(" | |    | | | | | |\\/| | |  _|     | |     | |     | | | | \\___ \\  |  _|   | |_) | \n");
   printf(" | |___ | |_| | | |  | | | |___    | |___  | |___  | |_| |  ___) | | |___  |  _ <  \n");
   printf(" \\____|  \\___/  |_|  |_| |_____|    \\____| |_____|  \\___/  |____/  |_____| |_| \\_\\ \n\n\n");
   printf("\n");
}

void menu(int value){
    /* OPCOES DO MENU
    *  CRIAR PERFIL
    *  BUSCAR PERFIL
    *  ATUALIZAR PERFIL
    */
    Funcs fun;

  switch(value){

    case 0: // criar
        // AO CRIAR NA TELA O PERFIL DO USUARIO QUE IRA BUSCAR OS OUTROS PERFIS, E NECESSARIO APARECER OS ATRIBUTOS QUE DEVERAM SER ESCOLHIDOS A PARTIR DE NUMEROS DE UM CONSOLE
        // POR EXEMPLO ATRIBUTO 1 - RELACIONAMENTO - AMIZADE, NAMORO, OUTROS
        {

            string name;
            string email; // validacao para criacao de perfil a partir do email da faculdade
            string gender;
            int age;
            string location; // curitiba
            string school;
            int attributes[4];

            cout << "Digite seu nome: ";
            cin.ignore(); // limpa o caracter de nova linha \n do buffer de entrada ou teclas indesejadas
            getline(cin, name); // l� o dado at� que uma nova linha seja detectada

            do{
                cout << "\nDigite seu e-mail: ";
                getline(cin, email);

                if(fun.validar_email(email) == false)
                {
                    cout << "\nApenas estudantes podem utilizar o aplicativo !" <<
                    "\nEntre com um email valido !" << endl;
                }

            } while(fun.validar_email(email) == false);

            cout << "\nSexo: ";
            cin >> gender;
            cout << "\nSua idade: ";
            cin >> age;
            cout << "\nSua Localizacao: ";
            cin.ignore();
            getline(cin, location);
            cout << "\nO que esta cursando : ";
            getline(cin, school);

            cout << "\nESCOLHA 4 CARACTERISTICAS QUE VOCE SE IDENTIFICA CONFORME OS NUMEROS INDICADOS: \n" << endl;
            cout << "1 - Esportes\n" << "2 - Sair\n" << "3 - Cinema\n" << "4 - Netflix\n" << "5 - Beber\n" << "6 - Viajar\n" << "7 - Ler\n" << "8 - Jogos\n" << "9 - Fazer Amizades\n" << "10 -Ficar em casa\n"
            << "11 - Pets" << endl;

            string numericos[] = { "primeira", "segunda", "terceira", "quarta" };

            for(int i = 0; i < 4; i++)
            {
                cout << "\nEscolha a " << numericos[i] << " caracteristica (0 para pular): ";
                cin >> attributes[i];
            }

            Profile user(name, email, gender, age, location, school, attributes);

            system("cls");

            user.displayProfile();
            user.save_profile();

            system("pause");
        }
      break;
    case 1:
        fun.load_profiles();
        break;
    case 2:

        Profile users[102];

        int attributes[4];
        int sexo = 0;
        int index = 0;

        percorrer("Users profile\\", index, users);

        cout << "\nESCOLHA 4 CARACTERISTICAS PARA REALIZAR A BUSCA DE PERFIS: \n" << endl;
        cout << "1 - Esportes\n" << "2 - Sair\n" << "3 - Cinema\n" << "4 - Netflix\n" << "5 - Beber\n" << "6 - Viajar\n" << "7 - Ler\n" << "8 - Jogos\n" << "9 - Fazer Amizades\n" << "10 -Ficar em casa\n"
        << "11 - Pets" << endl;

        string numericos[] = { "primeira", "segunda", "terceira", "quarta" };

        for(int i = 0; i < 4; i++)
        {
            cout << "\nEscolha a " << numericos[i] << " caracteristica (0 para pular): ";
            cin >> attributes[i];
        }

       /* cout << "Digite (1) para sexo masculino e (2) para sexo feminino" << endl;
        cin >> sexo;*/

        Attribute busca;

        for (int i = 1; i < 101; i++){
            busca.match(users[i], attributes, sexo);
        }
        break;
  }
}



int main()
{
    display();

    int op;

    cout << "\t\t\t\t0 - CRIAR PERFIL\n\n\n" <<
        "\t\t\t\t1 - CARREGAR PERFIL\n\n\n" <<
        "\t\t\t\t2 - BUSCAR PERFILS (MATCH)\n\n\n" <<
        "\t\t\t\t3 - ATUALIZAR PERFIL\n\n\n\n\n\n" << endl;
        //"PRESSIONE QUALQUER TECLA PARA SAIR" << endl;

    cin >> op;

    menu(op);

    return 0;
}
