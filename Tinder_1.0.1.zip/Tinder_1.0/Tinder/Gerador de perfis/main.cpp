#include <iostream>
#include<time.h>//necess�rio p/ fun��o time()
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <windows.h>

using namespace std;

int main()
{
    string nomes[] = { "Paula", "Ana", "Ariela", "Alana", "Cloe", "Jade", "Betina", "Leona", "Mia", "Louise", "Beatriz", "Marcela",
    "Ericka", "Leandra", "Barbara", "Lisa", "Eliza", "Pamella", "Brenda", "Deborah", "Gloria", "Fernanda", "Paola", "Cristina", "Sarah",
    "Rachel", "Jaqueline", "Priscilla", "Vanessa" };

    string nomes_M[] = { "Paulo", "Luis", "Ariel", "Igor", "Vinicius", "Fabricio", "Joaquim", "Noah", "Romulo", "Gabriel", "Rafael", "Leonardo",
    "Orlando", "Elias", "Miguel", "Lucas", "Davi", "Joao", "Daniel", "Matheus", "Samuel", "Andre", "Caio", "Danilo", "Felipe", "Fernando", "Leandro", "Eduardo", "Henrique", "Raul" };

    string cidades[] = { "Curitiba", "Pinhais", "Sao Jose dos Pinhais", "Piraquara", "Quatro Barras", "Araucaria", "Fazenda Rio Grande",
    "Campo Magro", "Campo Largo" };

    string cursos[] = {"Administracao", "Arquitetura e Urbanismo", "Ciencias Contabeis", "Design Grafico", "Educacao Fisica", "Agronomia", "Biomedicina", "Design de Interiores", "Direito",
    "Enfermagem", "Engenharia de Producao", "Analise e Desenvolvimento de Sistemas", "Ciencias da Computacao", "Design de Moda", "Engenharia Ambiental", "Fotografia", "Historia", "Jornalismo",
    "Medicina", "Odontologia", "Pedagogia" };

    char sexo[2] = {'M', 'F'};

    srand(time(NULL));

    char new_text[128];

    int contador = 1;

    do{
        Sleep(10);
        sprintf(new_text, "Users profile/profile%d.txt", contador);

        FILE * profile = fopen(new_text, "w+");

        int gender_rand = rand() % 2; // 2 opcoes

        Sleep(2);

        int name_rand = rand() % 28; // 29 nomes

        Sleep(2);

        int location_rand = rand() % 8; // 9 cidades

        Sleep(2);

        int age_rand = rand() % 40; // de 18 anos a 40 anos

        if(age_rand < 18)
        {
            int somador = 18 - age_rand;
            age_rand += somador;

            int somador2 = rand() % 14;

            age_rand += somador2;
        }

        Sleep(2);

        int attributes_rand[4];

        attributes_rand[0] = rand() % 11 + 1; // de 1 a 11

        Sleep(2);

        do{
            Sleep(1);
            attributes_rand[1] = rand() % 11 + 1; // de 1 a 11
        } while ( attributes_rand[1] == attributes_rand[0] );

        Sleep(2);

        do{
            Sleep(1);
            attributes_rand[2] = rand() % 11 + 1; // de 1 a 11
        } while ( attributes_rand[2] == attributes_rand[0]  || attributes_rand[2] == attributes_rand[1] );

        Sleep(2);

        do{
            Sleep(1);
            attributes_rand[3] = rand() % 11 + 1; // de 1 a 11
        } while ( attributes_rand[3] == attributes_rand[2]  || attributes_rand[3] == attributes_rand[1] || attributes_rand[3] == attributes_rand[0] );

        Sleep(2);

        int cursos_rand = rand() % 20; // 21 cursos

        int existe = 1;

        while(existe > 0)
        {
            existe = 0;
            for(int i = 0; i < 4; i++)
            {
                if(attributes_rand[i] > attributes_rand[i + 1])
                {
                    int aux = attributes_rand[i + 1];
                    attributes_rand[i + 1] = attributes_rand[i];
                    attributes_rand[i] = aux;

                    existe = 1;
                }
            }
        }

        if(gender_rand == 0)
        {
            fprintf(profile, "%s\n", nomes_M[name_rand].c_str());
            fprintf(profile, "%s@utp.edu.br\n", nomes_M[name_rand].c_str());
            fprintf(profile, "%c\n", sexo[gender_rand]);
            fprintf(profile, "%d\n", age_rand);
            fprintf(profile, "%s\n", cidades[location_rand].c_str());
            fprintf(profile, "%s\n", cursos[cursos_rand].c_str());
            fprintf(profile, "%d\n", attributes_rand[0]);
            fprintf(profile, "%d\n", attributes_rand[1]);
            fprintf(profile, "%d\n", attributes_rand[2]);
            fprintf(profile, "%d\n", attributes_rand[3]);

        } else {

            fprintf(profile, "%s\n", nomes[name_rand].c_str());
            fprintf(profile, "%s@utp.edu.br\n", nomes[name_rand].c_str());
            fprintf(profile, "%c\n", sexo[gender_rand]);
            fprintf(profile, "%d\n", age_rand);
            fprintf(profile, "%s\n", cidades[location_rand].c_str());
            fprintf(profile, "%s\n", cursos[cursos_rand].c_str());
            fprintf(profile, "%d\n", attributes_rand[0]);
            fprintf(profile, "%d\n", attributes_rand[1]);
            fprintf(profile, "%d\n", attributes_rand[2]);
            fprintf(profile, "%d\n", attributes_rand[3]);
        }

        fclose(profile);

        contador++;
    } while ( contador < 100);

    return 0;
}
