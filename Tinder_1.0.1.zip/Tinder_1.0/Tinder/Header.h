#ifndef _INCLUDES_
#define _INCLUDES_

#include <iostream>
#include <Windows.h>
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctime>
#include <string>
#include <process.h>
#include <cstdlib>
#include <cmath>
using namespace std;

#include "profile.h"
#include "funcoes.h"

#endif
